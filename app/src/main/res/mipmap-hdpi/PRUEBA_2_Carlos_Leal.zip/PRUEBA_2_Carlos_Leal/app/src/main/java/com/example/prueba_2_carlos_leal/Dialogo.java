package com.example.prueba_2_carlos_leal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Dialogo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialogo);
    }
}