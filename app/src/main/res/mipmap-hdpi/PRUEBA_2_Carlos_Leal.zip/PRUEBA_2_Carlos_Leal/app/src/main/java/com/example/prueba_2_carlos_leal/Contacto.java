package com.example.prueba_2_carlos_leal;

import android.text.Editable;

public class Contacto {
    public int getProducto;
    int producto;
    int id;
    String nombre;
    String apellido;
    String email;
    String telefono;
    String ciudad;
    String rut;
    String producto;
    String total;

    public Contacto() {

    }

    public Contacto(String nombre, String apellido, String email, String telefono, String ciudad, String rut, String producto, String total) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.telefono = telefono;
        this.ciudad = ciudad;
        this.rut= rut;
        this.producto = Integer.parseInt(producto);
        this.total= total;
    }

    public Contacto(int id, String nombre, String apellido, String email, String telefono, String ciudad, String rut, String producto, String total) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.telefono = telefono;
        this.ciudad = ciudad;
        this.rut= rut;
        this.producto = Integer.parseInt(producto);
        this.total = total;
    }

    public Contacto(int id, String toString, String toString1, String toString2, String toString3, String toString4, Editable text, String toString5, String toString6, String toString7) {
    }

    public Contacto(int anInt, String string, String string1, String string2, String string3, String string4) {
    }

    public int getId() {
        return 0;
    }

    public int getNombre() {
        return 0;
    }

    public int getApellido() {
        return 0;
    }

    public int getEmail() {
        return 0;
    }

    public int getTelefono() {
        return 0;
    }

    public int getCiudad() {
        return 0;
    }

    public int getRut() {
        return 0;
    }

    public int getTotal() {
        return 0;
    }
}